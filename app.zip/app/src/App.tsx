import { useState, useEffect } from 'react';
import { HomePage } from '@/sections/HomePage';
import { AdminLogin } from '@/sections/AdminLogin';
import { AdminPanel } from '@/sections/AdminPanel';
import { ScriptDetail } from '@/sections/ScriptDetail';
import { FolderDetail } from '@/sections/FolderDetail';
import { useScripts, useFolders, useChampions, useProfile, useAdminAuth } from '@/hooks/useFirestore';
import type { Script, Folder } from '@/types';
import './App.css';

type Page = 'home' | 'admin-login' | 'admin-panel' | 'script-detail' | 'folder-detail';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedScript, setSelectedScript] = useState<Script | null>(null);
  const [selectedFolder, setSelectedFolder] = useState<Folder | null>(null);
  
  const { scripts, addScript, updateScript, deleteScript, incrementViews, loaded: scriptsLoaded } = useScripts();
  const { folders, addFolder, deleteFolder, updateScriptCount, loaded: foldersLoaded } = useFolders();
  const { champions, addChampion, updateChampion, deleteChampion, loaded: championsLoaded } = useChampions();
  const { profile, updateProfile, loaded: profileLoaded } = useProfile();
  const { isAuthenticated, login } = useAdminAuth();

  // Check if already authenticated
  useEffect(() => {
    if (isAuthenticated && currentPage === 'admin-login') {
      setCurrentPage('admin-panel');
    }
  }, [isAuthenticated, currentPage]);

  const handleLogin = (password: string): boolean => {
    const success = login(password);
    if (success) {
      setCurrentPage('admin-panel');
    }
    return success;
  };

  const handleAddScript = async (scriptData: Omit<Script, 'id' | 'createdAt' | 'views'>) => {
    await addScript(scriptData);
    if (scriptData.folderId) {
      updateScriptCount(scriptData.folderId, 1);
    }
  };

  const handleDeleteScript = async (id: string) => {
    const script = scripts.find(s => s.id === id);
    if (script?.folderId) {
      updateScriptCount(script.folderId, -1);
    }
    await deleteScript(id);
  };

  const handleViewScript = (script: Script) => {
    setSelectedScript(script);
    incrementViews(script.id);
    setCurrentPage('script-detail');
  };

  const handleViewFolder = (folder: Folder) => {
    setSelectedFolder(folder);
    setCurrentPage('folder-detail');
  };

  const handleAddFolder = async (name: string) => {
    await addFolder(name);
  };

  const handleDeleteFolder = async (folderId: string) => {
    // Delete all scripts in this folder
    const scriptsInFolder = scripts.filter(s => s.folderId === folderId);
    for (const script of scriptsInFolder) {
      await deleteScript(script.id);
    }
    await deleteFolder(folderId);
  };

  // Show loading state while data is being loaded
  if (!scriptsLoaded || !foldersLoaded || !championsLoaded || !profileLoaded) {
    return (
      <div className="min-h-screen bg-[#E8F5E9] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#2E7D32] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-[#2E7D32] font-medium">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#E8F5E9]">
      {currentPage === 'home' && (
        <HomePage 
          scripts={scripts} 
          profile={profile}
          onNavigate={(page) => setCurrentPage(page as Page)}
          onViewScript={handleViewScript}
        />
      )}

      {currentPage === 'admin-login' && (
        <AdminLogin 
          onLogin={handleLogin}
          onBack={() => setCurrentPage('home')}
        />
      )}

      {currentPage === 'admin-panel' && (
        <AdminPanel
          scripts={scripts}
          folders={folders}
          champions={champions}
          profile={profile}
          onAddScript={handleAddScript}
          onUpdateScript={updateScript}
          onDeleteScript={handleDeleteScript}
          onAddChampion={async (c) => { await addChampion(c); }}
          onUpdateChampion={async (id, u) => { await updateChampion(id, u); }}
          onDeleteChampion={async (id) => { await deleteChampion(id); }}
          onAddFolder={handleAddFolder}
          onUpdateProfile={updateProfile}
          onViewWebsite={() => setCurrentPage('home')}
          onViewFolder={handleViewFolder}
        />
      )}

      {currentPage === 'script-detail' && selectedScript && (
        <ScriptDetail
          script={selectedScript}
          onBack={() => setCurrentPage('home')}
        />
      )}

      {currentPage === 'folder-detail' && selectedFolder && (
        <FolderDetail
          folder={selectedFolder}
          scripts={scripts}
          folders={folders}
          onBack={() => setCurrentPage('admin-panel')}
          onAddScript={handleAddScript}
          onUpdateScript={updateScript}
          onDeleteScript={handleDeleteScript}
          onDeleteFolder={handleDeleteFolder}
          onViewScript={handleViewScript}
        />
      )}
    </div>
  );
}

export default App;
