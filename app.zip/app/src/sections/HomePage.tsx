import { useState, useEffect } from 'react';
import { Search, Home, Clock, TrendingUp, Menu, Lock, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import type { Script } from '@/types';

interface HomePageProps {
  scripts: Script[];
  profile: {
    username: string;
    banner: string;
    avatar: string;
    description: string;
  };
  onNavigate: (page: string) => void;
  onViewScript: (script: Script) => void;
}

// Key for localStorage
const SEARCH_QUERY_KEY = 'mlbb_search_query';
const IS_SEARCHING_KEY = 'mlbb_is_searching';

export function HomePage({ scripts, profile, onNavigate, onViewScript }: HomePageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [activeCategory, setActiveCategory] = useState<'latest' | 'popular'>('latest');

  // Load search state from localStorage on mount
  useEffect(() => {
    const savedQuery = localStorage.getItem(SEARCH_QUERY_KEY);
    const savedIsSearching = localStorage.getItem(IS_SEARCHING_KEY);
    
    if (savedQuery && savedIsSearching === 'true') {
      setSearchQuery(savedQuery);
      setIsSearching(true);
    }
  }, []);

  // Save search state to localStorage whenever it changes
  useEffect(() => {
    if (searchQuery) {
      localStorage.setItem(SEARCH_QUERY_KEY, searchQuery);
      localStorage.setItem(IS_SEARCHING_KEY, isSearching ? 'true' : 'false');
    } else {
      localStorage.removeItem(SEARCH_QUERY_KEY);
      localStorage.removeItem(IS_SEARCHING_KEY);
    }
  }, [searchQuery, isSearching]);

  // Scripts for homepage display (only showOnHome = true)
  const homepageScripts = scripts.filter(script => script.showOnHome);

  // Scripts for search (show ALL scripts, regardless of showOnHome)
  const searchResults = scripts.filter(script => 
    script.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    script.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    script.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedHomepageScripts = activeCategory === 'latest' 
    ? [...homepageScripts].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    : [...homepageScripts].sort((a, b) => b.views - a.views);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    });
  };

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    setIsSearching(e.target.value.length > 0);
  };

  // Clear search
  const clearSearch = () => {
    setSearchQuery('');
    setIsSearching(false);
    localStorage.removeItem(SEARCH_QUERY_KEY);
    localStorage.removeItem(IS_SEARCHING_KEY);
  };

  // Handle view script - save search state before navigating
  const handleViewScript = (script: Script) => {
    // Save current search state
    if (searchQuery) {
      localStorage.setItem(SEARCH_QUERY_KEY, searchQuery);
      localStorage.setItem(IS_SEARCHING_KEY, 'true');
    }
    onViewScript(script);
  };

  return (
    <div className="min-h-screen bg-[#E8F5E9]">
      {/* Header */}
      <header className="bg-[#2E7D32] text-white px-4 py-3 flex items-center justify-between">
        <button className="p-2 hover:bg-white/10 rounded-lg transition-all duration-200 ease-out hover:scale-105 active:scale-95">
          <Menu className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-semibold">Home</h1>
        <button 
          onClick={() => onNavigate('admin-login')}
          className="p-2 hover:bg-white/10 rounded-lg transition-all duration-200 ease-out hover:scale-105 active:scale-95"
        >
          <Lock className="w-6 h-6" />
        </button>
      </header>

      {/* Banner */}
      <div className="relative">
        <div 
          className="h-48 bg-cover bg-center transition-all duration-500 ease-out"
          style={{ backgroundImage: `url(${profile.banner})` }}
        />
        <div className="absolute -bottom-16 left-1/2 transform -translate-x-1/2 transition-transform duration-300 ease-out">
          <div className="w-32 h-32 rounded-full border-4 border-[#E8F5E9] overflow-hidden bg-white shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-105">
            <img 
              src={profile.avatar} 
              alt="Profile" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Profile Info */}
      <div className="pt-20 px-4 text-center">
        <h2 className="text-2xl font-bold text-[#2E7D32] transition-all duration-300">{profile.username}</h2>
        <p className="text-gray-600 mt-2 whitespace-pre-line">{profile.description}</p>
      </div>

      {/* Search */}
      <div className="px-4 mt-6">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 transition-colors duration-200 group-focus-within:text-[#2E7D32]" />
          <Input
            type="text"
            placeholder="Cari script..."
            value={searchQuery}
            onChange={handleSearchChange}
            className="pl-12 pr-12 py-6 rounded-full bg-white border-2 border-transparent shadow-sm text-base transition-all duration-300 ease-out focus:border-[#2E7D32] focus:shadow-lg focus:ring-0 hover:shadow-md"
          />
          {searchQuery && (
            <button
              onClick={clearSearch}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 p-1 bg-gray-100 rounded-full hover:bg-gray-200 transition-all duration-200 ease-out hover:scale-110 active:scale-90"
            >
              <X className="w-4 h-4 text-gray-500" />
            </button>
          )}
        </div>
      </div>

      {/* Search Results or Normal Content */}
      {isSearching ? (
        /* Search Results - Show ALL scripts (including those not on homepage) */
        <div className="px-4 mt-6 pb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-[#2E7D32]">Hasil Pencarian</h3>
            <span className="text-sm text-gray-500">{searchResults.length} script ditemukan</span>
          </div>

          <div className="space-y-4">
            {searchResults.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                  <Search className="w-10 h-10 text-gray-400" />
                </div>
                <p className="text-gray-500 text-lg">Tidak ada script ditemukan</p>
                <p className="text-gray-400 text-sm mt-1">Coba kata kunci lain</p>
              </div>
            ) : (
              searchResults.map((script, index) => (
                <div 
                  key={script.id}
                  onClick={() => handleViewScript(script)}
                  className="bg-white rounded-2xl p-4 flex items-center gap-4 shadow-sm cursor-pointer transition-all duration-300 ease-out hover:shadow-lg hover:translate-y-[-2px] active:scale-[0.98]"
                  style={{
                    animation: `fadeInUp 0.4s ease-out ${index * 0.05}s both`
                  }}
                >
                  <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
                    <img 
                      src={script.thumbnail} 
                      alt={script.title}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-gray-900 truncate">{script.title}</h4>
                    <p className="text-sm text-gray-500 mt-1">{formatDate(script.createdAt)}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs px-2 py-1 bg-[#E8F5E9] text-[#2E7D32] rounded-full transition-all duration-200">
                        {script.category}
                      </span>
                      {script.views > 0 && (
                        <span className="text-xs text-gray-400">
                          {script.views} views
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      ) : (
        /* Normal Content - Only showOnHome scripts */
        <>
          {/* Categories */}
          <div className="px-4 mt-6">
            <div className="flex items-center gap-2 mb-4">
              <Home className="w-5 h-5 text-[#2E7D32]" />
              <h3 className="text-lg font-semibold text-[#2E7D32]">Kategori Beranda</h3>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={() => setActiveCategory('latest')}
                className={`flex-1 py-6 rounded-xl font-medium transition-all duration-300 ease-out ${
                  activeCategory === 'latest'
                    ? 'bg-[#2E7D32] text-white shadow-lg hover:bg-[#1B5E20] hover:shadow-xl hover:translate-y-[-1px]'
                    : 'bg-white text-gray-700 shadow-sm hover:shadow-md hover:translate-y-[-1px]'
                }`}
              >
                <Clock className="w-5 h-5 mr-2" />
                Postingan Terbaru
              </Button>
              <Button
                onClick={() => setActiveCategory('popular')}
                className={`flex-1 py-6 rounded-xl font-medium transition-all duration-300 ease-out ${
                  activeCategory === 'popular'
                    ? 'bg-[#2E7D32] text-white shadow-lg hover:bg-[#1B5E20] hover:shadow-xl hover:translate-y-[-1px]'
                    : 'bg-white text-gray-700 shadow-sm hover:shadow-md hover:translate-y-[-1px]'
                }`}
              >
                <TrendingUp className="w-5 h-5 mr-2" />
                Populer
              </Button>
            </div>
          </div>

          {/* Posts List - Only showOnHome scripts */}
          <div className="px-4 mt-6 pb-8">
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-5 h-5 text-[#2E7D32]" />
              <h3 className="text-lg font-semibold text-[#2E7D32]">
                {activeCategory === 'latest' ? 'Postingan Terbaru' : 'Postingan Populer'}
              </h3>
            </div>

            <div className="space-y-4">
              {sortedHomepageScripts.length === 0 ? (
                <div className="text-center py-12 bg-white rounded-2xl">
                  <p className="text-gray-500">Belum ada postingan</p>
                </div>
              ) : (
                sortedHomepageScripts.map((script, index) => (
                  <div 
                    key={script.id}
                    onClick={() => handleViewScript(script)}
                    className="bg-white rounded-2xl p-4 flex items-center gap-4 shadow-sm cursor-pointer transition-all duration-300 ease-out hover:shadow-lg hover:translate-y-[-2px] active:scale-[0.98]"
                    style={{
                      animation: `fadeInUp 0.4s ease-out ${index * 0.05}s both`
                    }}
                  >
                    <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
                      <img 
                        src={script.thumbnail} 
                        alt={script.title}
                        className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-gray-900 truncate">{script.title}</h4>
                      <p className="text-sm text-gray-500 mt-1">{formatDate(script.createdAt)}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-xs px-2 py-1 bg-[#E8F5E9] text-[#2E7D32] rounded-full transition-all duration-200">
                          {script.category}
                        </span>
                        {script.views > 0 && (
                          <span className="text-xs text-gray-400">
                            {script.views} views
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))
            )}
            </div>
          </div>
        </>
      )}

      {/* CSS Animations */}
      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
