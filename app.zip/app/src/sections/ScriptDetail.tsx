import { useEffect } from 'react';
import { ArrowLeft, Calendar, TrendingUp, ExternalLink } from 'lucide-react';
import type { Script } from '@/types';

interface ScriptDetailProps {
  script: Script;
  onBack: () => void;
}

// Function to detect and convert URLs to clickable links
function LinkifyText({ text }: { text: string }) {
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const parts = text.split(urlRegex);

  return (
    <>
      {parts.map((part, index) => {
        if (urlRegex.test(part)) {
          return (
            <a
              key={index}
              href={part}
              target="_blank"
              rel="noopener noreferrer"
              className="text-red-500 underline break-all hover:text-red-600 inline-flex items-center gap-1 transition-colors duration-200"
            >
              {part}
              <ExternalLink className="w-3 h-3 flex-shrink-0" />
            </a>
          );
        }
        return <span key={index}>{part}</span>;
      })}
    </>
  );
}

export function ScriptDetail({ script, onBack }: ScriptDetailProps) {
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    });
  };

  return (
    <div className="min-h-screen bg-[#E8F5E9] animate-slideIn">
      {/* Header */}
      <header className="bg-[#2E7D32] text-white px-4 py-4 flex items-center justify-between sticky top-0 z-10">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 hover:bg-white/10 px-3 py-2 rounded-lg transition-all duration-200 ease-out hover:scale-105 active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Kembali</span>
        </button>
        <h1 className="text-lg font-semibold truncate max-w-[150px]">{script.title}</h1>
        <div className="w-20"></div>
      </header>

      {/* Content */}
      <div className="p-4">
        {/* Title */}
        <h2 className="text-2xl font-bold text-gray-900 mb-4 animate-fadeIn">{script.title}</h2>

        {/* Banner Image */}
        <div className="w-full aspect-video rounded-2xl overflow-hidden mb-4 shadow-lg transition-all duration-500 hover:shadow-xl">
          <img 
            src={script.banner || script.thumbnail} 
            alt={script.title}
            className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
          />
        </div>

        {/* Meta Info */}
        <div className="flex items-center gap-4 mb-4 text-gray-600 animate-fadeIn" style={{ animationDelay: '0.1s' }}>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span className="text-sm">{formatDate(script.createdAt)}</span>
          </div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            <span className="text-sm">{script.views} views</span>
          </div>
        </div>

        {/* Category Badge */}
        <span className="inline-block px-4 py-2 bg-blue-100 text-blue-600 rounded-full text-sm font-medium mb-6 animate-fadeIn transition-all duration-300 hover:bg-blue-200" style={{ animationDelay: '0.15s' }}>
          {script.category}
        </span>

        {/* Description */}
        <div className="bg-white rounded-2xl p-5 shadow-sm transition-all duration-300 hover:shadow-md animate-fadeIn" style={{ animationDelay: '0.2s' }}>
          <div className="flex items-center gap-2 mb-4">
            <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <h3 className="font-semibold text-gray-900">Deskripsi</h3>
          </div>
          <div className="text-gray-700 whitespace-pre-wrap leading-relaxed">
            <LinkifyText text={script.description} />
          </div>
        </div>
      </div>

      {/* CSS Animations */}
      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(20px); }
          to { opacity: 1; transform: translateX(0); }
        }
        .animate-slideIn {
          animation: slideIn 0.4s ease-out;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.5s ease-out forwards;
        }
      `}</style>
    </div>
  );
}
