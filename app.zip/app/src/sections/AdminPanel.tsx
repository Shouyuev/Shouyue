import { useState } from 'react';
import { ArrowRight, FileText, Eye, Plus, Search, Folder, Upload, User, Edit, Trash2, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ImageCropper } from '@/components/ImageCropper';
import type { Script, Folder as FolderType, Champion } from '@/types';
import { CATEGORIES } from '@/types';

interface ProfileType {
  username: string;
  banner: string;
  avatar: string;
  description: string;
}

interface AdminPanelProps {
  scripts: Script[];
  folders: FolderType[];
  champions: Champion[];
  profile: ProfileType;
  onAddScript: (script: Omit<Script, 'id' | 'createdAt' | 'views'>) => Promise<void>;
  onUpdateScript: (id: string, updates: Partial<Script>) => Promise<void>;
  onDeleteScript: (id: string) => Promise<void>;
  onAddChampion: (champion: Omit<Champion, 'id'>) => Promise<void>;
  onUpdateChampion: (id: string, updates: Partial<Champion>) => Promise<void>;
  onDeleteChampion: (id: string) => Promise<void>;
  onAddFolder: (name: string) => Promise<void>;
  onUpdateProfile: (updates: Partial<ProfileType>) => void;
  onViewWebsite: () => void;
  onViewFolder: (folder: FolderType) => void;
}

export function AdminPanel({
  scripts,
  folders,
  champions,
  profile,
  onAddScript,
  onUpdateScript,
  onDeleteScript,
  onAddChampion,
  onUpdateChampion,
  onDeleteChampion,
  onAddFolder,
  onUpdateProfile,
  onViewWebsite,
  onViewFolder
}: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState('scripts');
  const [showAddScript, setShowAddScript] = useState(false);
  const [showAddChampion, setShowAddChampion] = useState(false);
  const [showAddFolder, setShowAddFolder] = useState(false);
  const [editingScript, setEditingScript] = useState<Script | null>(null);
  const [editingChampion, setEditingChampion] = useState<Champion | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [folderSearchQuery, setFolderSearchQuery] = useState('');

  const totalViews = scripts.reduce((sum, s) => sum + s.views, 0);

  // Get scripts without folder
  const scriptsWithoutFolder = scripts.filter(s => !s.folderId);

  const filteredFolders = folders.filter(f => 
    f.name.toLowerCase().includes(folderSearchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#E8F5E9] animate-fadeIn">
      {/* Header */}
      <header className="bg-[#2E7D32] text-white px-4 py-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold">Admin Panel</h1>
          <button 
            onClick={onViewWebsite}
            className="flex items-center gap-2 text-sm hover:underline transition-all duration-200 ease-out hover:scale-105 active:scale-95"
          >
            Lihat Website
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Tabs */}
      <div className="px-4 py-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 bg-white rounded-xl p-1 transition-all duration-300">
            <TabsTrigger 
              value="profile" 
              className="rounded-lg data-[state=active]:bg-[#2E7D32] data-[state=active]:text-white transition-all duration-300"
            >
              <Upload className="w-4 h-4 mr-2" />
              Profile
            </TabsTrigger>
            <TabsTrigger 
              value="scripts"
              className="rounded-lg data-[state=active]:bg-[#2E7D32] data-[state=active]:text-white transition-all duration-300"
            >
              <FileText className="w-4 h-4 mr-2" />
              Scripts
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="mt-4 animate-slideIn">
            <ProfileTab 
              profile={profile} 
              onUpdate={onUpdateProfile}
            />
          </TabsContent>

          <TabsContent value="scripts" className="mt-4 animate-slideIn">
            <ScriptsTab
              scripts={scripts}
              scriptsWithoutFolder={scriptsWithoutFolder}
              champions={champions}
              totalViews={totalViews}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              folderSearchQuery={folderSearchQuery}
              setFolderSearchQuery={setFolderSearchQuery}
              filteredFolders={filteredFolders}
              onAddScript={() => setShowAddScript(true)}
              onAddFolder={() => setShowAddFolder(true)}
              onEditScript={setEditingScript}
              onDeleteScript={onDeleteScript}
              onEditChampion={setEditingChampion}
              onDeleteChampion={onDeleteChampion}
              onViewFolder={onViewFolder}
            />
          </TabsContent>
        </Tabs>
      </div>

      {/* Add/Edit Script Dialog */}
      <Dialog open={showAddScript || !!editingScript} onOpenChange={(open) => {
        if (!open) {
          setShowAddScript(false);
          setEditingScript(null);
        }
      }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto animate-scaleIn">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">
              {editingScript ? 'Edit Script' : 'Tambah Script'}
            </DialogTitle>
          </DialogHeader>
          <ScriptForm
            key={editingScript ? `edit-${editingScript.id}` : 'add-new'}
            folders={folders}
            initialData={editingScript}
            onSubmit={async (data) => {
              if (editingScript) {
                await onUpdateScript(editingScript.id, data);
                setEditingScript(null);
              } else {
                await onAddScript(data);
                setShowAddScript(false);
              }
            }}
            onCancel={() => {
              setShowAddScript(false);
              setEditingScript(null);
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Add/Edit Champion Dialog */}
      <Dialog open={showAddChampion || !!editingChampion} onOpenChange={(open) => {
        if (!open) {
          setShowAddChampion(false);
          setEditingChampion(null);
        }
      }}>
        <DialogContent className="max-w-lg animate-scaleIn">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">
              {editingChampion ? 'Edit Champion' : 'Tambah Champion'}
            </DialogTitle>
          </DialogHeader>
          <ChampionForm
            initialData={editingChampion}
            onSubmit={async (data) => {
              if (editingChampion) {
                await onUpdateChampion(editingChampion.id, data);
                setEditingChampion(null);
              } else {
                await onAddChampion(data);
                setShowAddChampion(false);
              }
            }}
            onCancel={() => {
              setShowAddChampion(false);
              setEditingChampion(null);
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Add Folder Dialog */}
      <Dialog open={showAddFolder} onOpenChange={setShowAddFolder}>
        <DialogContent className="max-w-md animate-scaleIn">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Tambah Folder</DialogTitle>
          </DialogHeader>
          <FolderForm
            onSubmit={async (name) => {
              await onAddFolder(name);
              setShowAddFolder(false);
            }}
            onCancel={() => setShowAddFolder(false)}
          />
        </DialogContent>
      </Dialog>

      {/* CSS Animations */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fadeIn {
          animation: fadeIn 0.4s ease-out;
        }
        @keyframes slideIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-slideIn {
          animation: slideIn 0.3s ease-out;
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-scaleIn {
          animation: scaleIn 0.2s ease-out;
        }
      `}</style>
    </div>
  );
}

function ProfileTab({ 
  profile, 
  onUpdate 
}: { 
  profile: { username: string; banner: string; avatar: string; description: string };
  onUpdate: (updates: Partial<typeof profile>) => void;
}) {
  const [bannerPreview, setBannerPreview] = useState(profile.banner);
  const [avatarPreview, setAvatarPreview] = useState(profile.avatar);
  const [cropImage, setCropImage] = useState<string | null>(null);
  const [cropAspect, setCropAspect] = useState<number>(16/9);
  const [cropCallback, setCropCallback] = useState<((cropped: string) => void) | null>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>, aspect: number, callback: (img: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCropImage(reader.result as string);
        setCropAspect(aspect);
        setCropCallback(() => callback);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCropComplete = (croppedImage: string) => {
    if (cropCallback) {
      cropCallback(croppedImage);
    }
    setCropImage(null);
    setCropCallback(null);
  };

  return (
    <div className="bg-white rounded-2xl p-6 transition-all duration-300 hover:shadow-lg">
      <h2 className="text-xl font-bold text-[#2E7D32] mb-6">Edit Profile</h2>

      {/* Image Cropper Modal */}
      {cropImage && (
        <ImageCropper
          image={cropImage}
          aspect={cropAspect}
          onCropComplete={handleCropComplete}
          onCancel={() => {
            setCropImage(null);
            setCropCallback(null);
          }}
        />
      )}

      {/* Banner Upload */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Banner (16:9)
        </label>
        <div className="relative">
          <input
            type="file"
            accept="image/*"
            onChange={(e) => handleImageSelect(e, 16/9, (img) => {
              setBannerPreview(img);
              onUpdate({ banner: img });
            })}
            className="hidden"
            id="banner-upload"
          />
          <label 
            htmlFor="banner-upload"
            className="block w-full aspect-video rounded-xl border-2 border-dashed border-[#2E7D32] bg-[#E8F5E9] cursor-pointer overflow-hidden transition-all duration-300 hover:border-[#1B5E20] hover:bg-[#D4EDDA] hover:shadow-md"
          >
            {bannerPreview ? (
              <img src={bannerPreview} alt="Banner" className="w-full h-full object-cover transition-transform duration-500 hover:scale-105" />
            ) : (
              <div className="flex flex-col items-center justify-center h-full">
                <Upload className="w-8 h-8 text-[#2E7D32] mb-2 transition-transform duration-300" />
                <span className="text-sm text-[#2E7D32]">Klik untuk upload & crop banner</span>
              </div>
            )}
          </label>
        </div>
      </div>

      {/* Avatar Upload */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Avatar (1:1)
        </label>
        <div className="relative">
          <input
            type="file"
            accept="image/*"
            onChange={(e) => handleImageSelect(e, 1, (img) => {
              setAvatarPreview(img);
              onUpdate({ avatar: img });
            })}
            className="hidden"
            id="avatar-upload"
          />
          <label 
            htmlFor="avatar-upload"
            className="block w-32 h-32 rounded-full border-2 border-dashed border-[#2E7D32] bg-[#E8F5E9] cursor-pointer overflow-hidden mx-auto transition-all duration-300 hover:border-[#1B5E20] hover:bg-[#D4EDDA] hover:shadow-md hover:scale-105"
          >
            {avatarPreview ? (
              <img src={avatarPreview} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <div className="flex flex-col items-center justify-center h-full">
                <Upload className="w-6 h-6 text-[#2E7D32] transition-transform duration-300" />
              </div>
            )}
          </label>
        </div>
      </div>

      {/* Username */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Username
        </label>
        <Input
          value={profile.username}
          onChange={(e) => onUpdate({ username: e.target.value })}
          className="w-full transition-all duration-300 focus:ring-2 focus:ring-[#2E7D32]"
        />
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Deskripsi
        </label>
        <textarea
          value={profile.description}
          onChange={(e) => onUpdate({ description: e.target.value })}
          rows={3}
          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#2E7D32] focus:ring-2 focus:ring-[#2E7D32] outline-none resize-none transition-all duration-300"
        />
      </div>
    </div>
  );
}

function ScriptsTab({
  scripts,
  scriptsWithoutFolder,
  champions,
  totalViews,
  searchQuery,
  setSearchQuery,
  folderSearchQuery,
  setFolderSearchQuery,
  filteredFolders,
  onAddScript,
  onAddFolder,
  onEditScript,
  onDeleteScript,
  onEditChampion,
  onDeleteChampion,
  onViewFolder
}: {
  scripts: Script[];
  scriptsWithoutFolder: Script[];
  champions: Champion[];
  totalViews: number;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  folderSearchQuery: string;
  setFolderSearchQuery: (q: string) => void;
  filteredFolders: FolderType[];
  onAddScript: () => void;
  onAddFolder: () => void;
  onEditScript: (script: Script) => void;
  onDeleteScript: (id: string) => void;
  onEditChampion: (champion: Champion) => void;
  onDeleteChampion: (id: string) => void;
  onViewFolder: (folder: FolderType) => void;
}) {
  const [view, setView] = useState<'dashboard' | 'champions'>('dashboard');

  if (view === 'champions') {
    return (
      <div className="animate-slideIn">
        {/* Champions Header */}
        <div className="bg-[#2E7D32] text-white px-4 py-3 flex items-center justify-between mb-4 rounded-xl">
          <button 
            onClick={() => setView('dashboard')}
            className="flex items-center gap-2 transition-all duration-200 hover:scale-105 active:scale-95"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Kembali</span>
          </button>
          <h2 className="text-lg font-semibold">CHAMPION</h2>
          <button onClick={() => {}} className="flex items-center gap-2 opacity-0">
            <span>Lihat Website</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="px-4">
          {/* Search */}
          <div className="flex gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                type="text"
                placeholder="Cari script..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-3 rounded-xl bg-white border-0 transition-all duration-300 focus:ring-2 focus:ring-[#2E7D32]"
              />
            </div>
          </div>

          {/* Champions List */}
          <div className="space-y-3">
            {champions
              .filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase()))
              .map((champion, index) => (
              <div 
                key={champion.id}
                className="bg-white rounded-xl p-4 flex items-center gap-4 transition-all duration-300 hover:shadow-lg hover:translate-y-[-2px]"
                style={{ animation: `fadeInUp 0.3s ease-out ${index * 0.05}s both` }}
              >
                <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0">
                  <img 
                    src={champion.thumbnail} 
                    alt={champion.name}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                  />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900">{champion.name} Champion</h4>
                  <span className="text-sm text-gray-500">{champion.role}</span>
                </div>
                <button 
                  onClick={() => onEditChampion(champion)}
                  className="p-2 text-gray-400 hover:text-[#2E7D32] transition-all duration-200 hover:scale-110"
                >
                  <Edit className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => onDeleteChampion(champion.id)}
                  className="p-2 text-gray-400 hover:text-red-500 transition-all duration-200 hover:scale-110"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-slideIn">
      {/* Stats */}
      <div className="bg-white rounded-2xl p-6 transition-all duration-300 hover:shadow-lg">
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center transition-all duration-300 hover:scale-105">
            <div className="w-12 h-12 bg-[#E8F5E9] rounded-full flex items-center justify-center mx-auto mb-2 transition-all duration-300">
              <FileText className="w-6 h-6 text-[#2E7D32]" />
            </div>
            <div className="text-3xl font-bold text-gray-900">{scripts.length}</div>
            <div className="text-sm text-gray-500">Total Scripts</div>
          </div>
          <div className="text-center transition-all duration-300 hover:scale-105">
            <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-2 transition-all duration-300">
              <Eye className="w-6 h-6 text-blue-500" />
            </div>
            <div className="text-3xl font-bold text-gray-900">{totalViews}</div>
            <div className="text-sm text-gray-500">Total Views</div>
          </div>
        </div>
      </div>

      {/* Add Script Button */}
      <Button
        onClick={onAddScript}
        className="w-full py-6 bg-[#2E7D32] hover:bg-[#1B5E20] text-white rounded-xl font-medium transition-all duration-300 ease-out hover:shadow-lg hover:translate-y-[-2px] active:translate-y-0"
      >
        <Plus className="w-5 h-5 mr-2" />
        Tambah Script
      </Button>

      {/* Folder SQUAD */}
      <div className="bg-white rounded-2xl p-6 transition-all duration-300 hover:shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-[#2E7D32]">Folder SQUAD</h3>
          <Button 
            onClick={onAddFolder}
            className="bg-[#2E7D32] hover:bg-[#1B5E20] text-white rounded-xl px-3 py-2 transition-all duration-300 hover:shadow-lg hover:scale-105 active:scale-95"
          >
            <Plus className="w-5 h-5" />
          </Button>
        </div>

        {/* Search Folders */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            type="text"
            placeholder="Cari folder..."
            value={folderSearchQuery}
            onChange={(e) => setFolderSearchQuery(e.target.value)}
            className="pl-10 pr-4 py-3 rounded-xl bg-gray-50 border-0 transition-all duration-300 focus:ring-2 focus:ring-[#2E7D32]"
          />
        </div>

        {/* Folders Grid */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          {filteredFolders.map((folder, index) => {
            // Calculate actual script count from scripts array
            const actualScriptCount = scripts.filter(s => s.folderId === folder.id).length;
            return (
              <div 
                key={folder.id}
                onClick={() => onViewFolder(folder)}
                className="bg-white border border-gray-100 rounded-xl p-4 flex items-center gap-3 cursor-pointer transition-all duration-300 hover:shadow-lg hover:translate-y-[-2px] hover:border-[#2E7D32] active:scale-[0.98]"
                style={{ animation: `fadeInUp 0.3s ease-out ${index * 0.03}s both` }}
              >
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0 transition-all duration-300">
                  <Folder className="w-5 h-5 text-purple-500" />
                </div>
                <div className="min-w-0">
                  <h4 className="font-medium text-gray-900 truncate">{folder.name}</h4>
                  <p className="text-sm text-gray-500">{actualScriptCount} script</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Scripts Without Folder */}
        {scriptsWithoutFolder.length > 0 && (
          <div className="mt-6 pt-6 border-t border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-600">Script Tanpa Folder</h3>
              <span className="text-sm text-gray-500">{scriptsWithoutFolder.length} script</span>
            </div>
            <div className="space-y-3">
              {scriptsWithoutFolder.map((script, index) => (
                <div 
                  key={script.id}
                  className="bg-gray-50 rounded-xl p-4 flex items-center gap-4 transition-all duration-300 hover:shadow-md hover:bg-white"
                  style={{ animation: `fadeInUp 0.3s ease-out ${index * 0.05}s both` }}
                >
                  <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                    <img 
                      src={script.thumbnail} 
                      alt={script.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-gray-900 truncate">{script.title}</h4>
                    <span className="text-xs px-2 py-1 bg-[#E8F5E9] text-[#2E7D32] rounded-full mt-1 inline-block">
                      {script.category}
                    </span>
                  </div>
                  <button 
                    onClick={() => onEditScript(script)}
                    className="p-2 text-gray-400 hover:text-[#2E7D32] transition-all duration-200 hover:scale-110"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => onDeleteScript(script.id)}
                    className="p-2 text-gray-400 hover:text-red-500 transition-all duration-200 hover:scale-110"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* CSS Animations */}
      <style>{`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(15px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

function FolderForm({
  onSubmit,
  onCancel
}: {
  onSubmit: (name: string) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onSubmit(name.trim());
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nama folder..."
          className="w-full py-4 transition-all duration-300 focus:ring-2 focus:ring-[#2E7D32]"
          autoFocus
        />
      </div>
      <div className="flex gap-3">
        <Button
          type="button"
          onClick={onCancel}
          variant="outline"
          className="flex-1 py-4 border-2 border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-all duration-300 hover:border-gray-300"
        >
          Batal
        </Button>
        <Button
          type="submit"
          className="flex-1 py-4 bg-[#2E7D32] hover:bg-[#1B5E20] text-white rounded-xl font-medium transition-all duration-300 hover:shadow-lg"
        >
          Tambah
        </Button>
      </div>
    </form>
  );
}

function ScriptForm({
  folders,
  initialData,
  onSubmit,
  onCancel
}: {
  folders: FolderType[];
  initialData: Script | null;
  onSubmit: (data: any) => void;
  onCancel: () => void;
}) {
  const [formData, setFormData] = useState({
    title: initialData?.title || '',
    description: initialData?.description || '',
    thumbnail: initialData?.thumbnail || '',
    banner: initialData?.banner || '',
    folderId: initialData?.folderId || '',
    showOnHome: initialData?.showOnHome ?? true,
    category: initialData?.category || 'ASSASIN'
  });

  const [thumbnailPreview, setThumbnailPreview] = useState(initialData?.thumbnail || '');
  const [bannerPreview, setBannerPreview] = useState(initialData?.banner || '');
  const [cropImage, setCropImage] = useState<string | null>(null);
  const [cropAspect, setCropAspect] = useState<number>(1);
  const [cropCallback, setCropCallback] = useState<((cropped: string) => void) | null>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>, aspect: number, callback: (img: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCropImage(reader.result as string);
        setCropAspect(aspect);
        setCropCallback(() => callback);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCropComplete = (croppedImage: string) => {
    if (cropCallback) {
      cropCallback(croppedImage);
    }
    setCropImage(null);
    setCropCallback(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Image Cropper Modal */}
      {cropImage && (
        <ImageCropper
          image={cropImage}
          aspect={cropAspect}
          onCropComplete={handleCropComplete}
          onCancel={() => {
            setCropImage(null);
            setCropCallback(null);
          }}
        />
      )}

      {/* Thumbnail Upload */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Thumbnail (1:1) - Untuk Card <span className="text-red-500">*</span>
        </label>
        <div className="relative">
          <input
            type="file"
            accept="image/*"
            onChange={(e) => handleImageSelect(e, 1, (img) => {
              setThumbnailPreview(img);
              setFormData(prev => ({ ...prev, thumbnail: img }));
            })}
            className="hidden"
            id="script-thumbnail"
          />
          <label 
            htmlFor="script-thumbnail"
            className="block w-full aspect-square max-w-[200px] mx-auto rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 cursor-pointer overflow-hidden transition-all duration-300 hover:border-[#2E7D32] hover:bg-[#E8F5E9]"
          >
            {thumbnailPreview ? (
              <img src={thumbnailPreview} alt="Thumbnail" className="w-full h-full object-cover transition-transform duration-500 hover:scale-105" />
            ) : (
              <div className="flex flex-col items-center justify-center h-full">
                <div className="w-12 h-12 bg-gray-200 rounded-lg flex items-center justify-center mb-2 transition-all duration-300">
                  <Upload className="w-6 h-6 text-gray-400" />
                </div>
                <span className="text-sm text-gray-500 text-center px-4">Klik untuk upload thumbnail 1:1</span>
              </div>
            )}
          </label>
        </div>
      </div>

      {/* Banner Upload */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Banner (16:9) - Untuk Detail
        </label>
        <div className="relative">
          <input
            type="file"
            accept="image/*"
            onChange={(e) => handleImageSelect(e, 16/9, (img) => {
              setBannerPreview(img);
              setFormData(prev => ({ ...prev, banner: img }));
            })}
            className="hidden"
            id="script-banner"
          />
          <label 
            htmlFor="script-banner"
            className="block w-full aspect-video rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 cursor-pointer overflow-hidden transition-all duration-300 hover:border-[#2E7D32] hover:bg-[#E8F5E9]"
          >
            {bannerPreview ? (
              <img src={bannerPreview} alt="Banner" className="w-full h-full object-cover transition-transform duration-500 hover:scale-105" />
            ) : (
              <div className="flex flex-col items-center justify-center h-full">
                <div className="w-12 h-12 bg-gray-200 rounded-lg flex items-center justify-center mb-2 transition-all duration-300">
                  <Upload className="w-6 h-6 text-gray-400" />
                </div>
                <span className="text-sm text-gray-500">Klik untuk upload banner 16:9</span>
                <span className="text-xs text-gray-400 mt-1">(Opsional - jika kosong akan pakai thumbnail)</span>
              </div>
            )}
          </label>
        </div>
      </div>

      {/* Title */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Judul <span className="text-red-500">*</span>
        </label>
        <Input
          value={formData.title}
          onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
          placeholder="Script Skin..."
          className="w-full transition-all duration-300 focus:ring-2 focus:ring-[#2E7D32]"
          required
        />
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Deskripsi & Link
        </label>
        <textarea
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          placeholder="Deskripsi dan link script..."
          rows={4}
          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#2E7D32] focus:ring-2 focus:ring-[#2E7D32] outline-none resize-none transition-all duration-300"
        />
        <p className="text-xs text-gray-500 mt-1">Link akan otomatis bisa diklik</p>
      </div>

      {/* Select Folder */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Pilih Folder
        </label>
        <select
          value={formData.folderId}
          onChange={(e) => setFormData(prev => ({ ...prev, folderId: e.target.value }))}
          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#2E7D32] focus:ring-2 focus:ring-[#2E7D32] outline-none bg-white transition-all duration-300"
        >
          <option value="">Tanpa Folder</option>
          {folders.map(folder => (
            <option key={folder.id} value={folder.id}>{folder.name}</option>
          ))}
        </select>
      </div>

      {/* Show on Home */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Tampil di Beranda
        </label>
        <div className="flex gap-3">
          <button
            type="button"
            onClick={() => setFormData(prev => ({ ...prev, showOnHome: true }))}
            className={`flex-1 py-3 px-4 rounded-xl border-2 flex items-center justify-center gap-2 transition-all duration-300 ${
              formData.showOnHome 
                ? 'border-[#2E7D32] bg-[#2E7D32] text-white' 
                : 'border-gray-200 text-gray-700 hover:border-[#2E7D32]'
            }`}
          >
            <User className="w-4 h-4" />
            Tampil di Beranda
          </button>
          <button
            type="button"
            onClick={() => setFormData(prev => ({ ...prev, showOnHome: false }))}
            className={`flex-1 py-3 px-4 rounded-xl border-2 flex items-center justify-center gap-2 transition-all duration-300 ${
              !formData.showOnHome 
                ? 'border-[#2E7D32] bg-[#2E7D32] text-white' 
                : 'border-gray-200 text-gray-700 hover:border-[#2E7D32]'
            }`}
          >
            Tidak di Beranda
          </button>
        </div>
        <div className="flex items-start gap-2 mt-2">
          <span className="text-yellow-500">💡</span>
          <p className="text-xs text-gray-500">Pilih "Tampil di Beranda" agar script muncul di halaman utama</p>
        </div>
      </div>

      {/* Category */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Kategori
        </label>
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, category: cat }))}
              className={`px-4 py-2 rounded-full border-2 text-sm font-medium transition-all duration-300 ${
                formData.category === cat
                  ? 'border-[#2E7D32] bg-[#2E7D32] text-white'
                  : 'border-gray-200 text-gray-700 hover:border-[#2E7D32]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Buttons */}
      <div className="flex gap-3 pt-4">
        <Button
          type="button"
          onClick={onCancel}
          variant="outline"
          className="flex-1 py-4 border-2 border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-all duration-300 hover:border-gray-300"
        >
          Batal
        </Button>
        <Button
          type="submit"
          className="flex-1 py-4 bg-[#2E7D32] hover:bg-[#1B5E20] text-white rounded-xl font-medium transition-all duration-300 hover:shadow-lg hover:translate-y-[-1px]"
        >
          {initialData ? 'Simpan' : 'Tambah'}
        </Button>
      </div>
    </form>
  );
}

function ChampionForm({
  initialData,
  onSubmit,
  onCancel
}: {
  initialData: Champion | null;
  onSubmit: (data: any) => void;
  onCancel: () => void;
}) {
  const [formData, setFormData] = useState<{
    name: string;
    role: 'ASSASIN' | 'MAGE' | 'MARKSMAN' | 'TANK' | 'FIGHTER' | 'SUPPORT';
    thumbnail: string;
  }>({
    name: initialData?.name || '',
    role: initialData?.role || 'ASSASIN',
    thumbnail: initialData?.thumbnail || ''
  });

  const [thumbnailPreview, setThumbnailPreview] = useState(initialData?.thumbnail || '');
  const [cropImage, setCropImage] = useState<string | null>(null);

  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCropImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCropComplete = (croppedImage: string) => {
    setThumbnailPreview(croppedImage);
    setFormData(prev => ({ ...prev, thumbnail: croppedImage }));
    setCropImage(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Image Cropper Modal */}
      {cropImage && (
        <ImageCropper
          image={cropImage}
          aspect={1}
          onCropComplete={handleCropComplete}
          onCancel={() => setCropImage(null)}
        />
      )}

      {/* Thumbnail Upload */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Thumbnail (1:1)
        </label>
        <div className="relative">
          <input
            type="file"
            accept="image/*"
            onChange={handleThumbnailChange}
            className="hidden"
            id="champion-thumbnail"
          />
          <label 
            htmlFor="champion-thumbnail"
            className="block w-32 h-32 mx-auto rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 cursor-pointer overflow-hidden transition-all duration-300 hover:border-[#2E7D32] hover:bg-[#E8F5E9]"
          >
            {thumbnailPreview ? (
              <img src={thumbnailPreview} alt="Thumbnail" className="w-full h-full object-cover" />
            ) : (
              <div className="flex flex-col items-center justify-center h-full">
                <Upload className="w-6 h-6 text-gray-400 mb-1" />
                <span className="text-xs text-gray-500">Upload</span>
              </div>
            )}
          </label>
        </div>
      </div>

      {/* Name */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Nama Champion
        </label>
        <Input
          value={formData.name}
          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
          placeholder="Nama champion..."
          className="w-full transition-all duration-300 focus:ring-2 focus:ring-[#2E7D32]"
          required
        />
      </div>

      {/* Role */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Role
        </label>
        <select
          value={formData.role}
          onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value as any }))}
          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#2E7D32] focus:ring-2 focus:ring-[#2E7D32] outline-none bg-white transition-all duration-300"
        >
          <option value="ASSASIN">ASSASIN</option>
          <option value="MAGE">MAGE</option>
          <option value="MARKSMAN">MARKSMAN</option>
          <option value="TANK">TANK</option>
          <option value="FIGHTER">FIGHTER</option>
          <option value="SUPPORT">SUPPORT</option>
        </select>
      </div>

      {/* Buttons */}
      <div className="flex gap-3 pt-4">
        <Button
          type="button"
          onClick={onCancel}
          variant="outline"
          className="flex-1 py-4 border-2 border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-all duration-300 hover:border-gray-300"
        >
          Batal
        </Button>
        <Button
          type="submit"
          className="flex-1 py-4 bg-[#2E7D32] hover:bg-[#1B5E20] text-white rounded-xl font-medium transition-all duration-300 hover:shadow-lg"
        >
          {initialData ? 'Simpan' : 'Tambah'}
        </Button>
      </div>
    </form>
  );
}
