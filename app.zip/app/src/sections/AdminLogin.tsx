import { useState } from 'react';
import { Shield, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface AdminLoginProps {
  onLogin: (password: string) => boolean;
  onBack: () => void;
}

export function AdminLogin({ onLogin, onBack }: AdminLoginProps) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    setTimeout(() => {
      if (onLogin(password)) {
        setError('');
      } else {
        setError('Password salah!');
      }
      setIsLoading(false);
    }, 300);
  };

  return (
    <div className="min-h-screen bg-[#E8F5E9] flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-lg p-8 transition-all duration-500 ease-out hover:shadow-xl">
        {/* Secure Badge */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#E8F5E9] rounded-full transition-all duration-300 hover:bg-[#D4EDDA]">
            <Shield className="w-4 h-4 text-[#2E7D32]" />
            <span className="text-sm text-[#2E7D32] font-medium">Secure Connection</span>
          </div>
        </div>

        {/* Lock Icon */}
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 flex items-center justify-center bg-[#E8F5E9] rounded-full transition-all duration-300 hover:scale-110">
            <Lock className="w-8 h-8 text-[#2E7D32]" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-3xl font-bold text-center text-[#2E7D32] mb-2">
          Admin Login
        </h1>
        <p className="text-center text-gray-500 mb-8">
          Reizen Official Admin Panel
        </p>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Password
            </label>
            <Input
              type="password"
              placeholder="Masukkan password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-4 rounded-xl border-2 border-gray-200 transition-all duration-300 focus:border-[#2E7D32] focus:ring-0 hover:border-gray-300"
            />
          </div>

          {error && (
            <p className="text-red-500 text-sm text-center animate-shake">{error}</p>
          )}

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full py-4 bg-[#2E7D32] hover:bg-[#1B5E20] text-white rounded-xl font-medium transition-all duration-300 ease-out hover:shadow-lg hover:translate-y-[-1px] active:translate-y-0 disabled:opacity-70"
          >
            {isLoading ? (
              <span className="flex items-center justify-center gap-2">
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Loading...
              </span>
            ) : (
              'Login'
            )}
          </Button>

          <Button
            type="button"
            onClick={onBack}
            variant="outline"
            className="w-full py-4 border-2 border-gray-200 text-gray-700 rounded-xl font-medium transition-all duration-300 ease-out hover:bg-gray-50 hover:border-gray-300 active:scale-[0.98]"
          >
            Kembali
          </Button>
        </form>

        {/* Footer */}
        <p className="text-center text-sm text-gray-400 mt-8">
          Dilindungi oleh sistem keamanan Reizen Official
        </p>
      </div>

      {/* CSS Animations */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.5s ease-out;
        }
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
          20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        .animate-shake {
          animation: shake 0.5s ease-in-out;
        }
      `}</style>
    </div>
  );
}
