import { useState, useEffect } from 'react';
import { ArrowLeft, Search, Plus, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ImageCropper } from '@/components/ImageCropper';
import type { Script, Folder } from '@/types';
import { CATEGORIES } from '@/types';
import { Upload, User } from 'lucide-react';

interface FolderDetailProps {
  folder: Folder;
  scripts: Script[];
  folders: Folder[];
  onBack: () => void;
  onAddScript: (script: Omit<Script, 'id' | 'createdAt' | 'views'>) => Promise<void>;
  onUpdateScript: (id: string, updates: Partial<Script>) => Promise<void>;
  onDeleteScript: (id: string) => Promise<void>;
  onDeleteFolder: (id: string) => Promise<void>;
  onViewScript: (script: Script) => void;
}

export function FolderDetail({ 
  folder, 
  scripts, 
  folders,
  onBack, 
  onAddScript,
  onUpdateScript,
  onDeleteScript,
  onDeleteFolder,
  onViewScript
}: FolderDetailProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddScript, setShowAddScript] = useState(false);
  const [showEditScript, setShowEditScript] = useState(false);
  const [editingScript, setEditingScript] = useState<Script | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const folderScripts = scripts.filter(s => 
    s.folderId === folder.id &&
    (s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
     s.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    });
  };

  const handleEditScript = (script: Script) => {
    setEditingScript(script);
    setShowEditScript(true);
  };

  const handleDeleteFolder = async () => {
    await onDeleteFolder(folder.id);
    setShowDeleteConfirm(false);
    onBack();
  };

  return (
    <div className="min-h-screen bg-[#E8F5E9] animate-slideIn">
      {/* Header */}
      <header className="bg-[#2E7D32] text-white px-4 py-4 flex items-center justify-between sticky top-0 z-10">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 hover:bg-white/10 px-3 py-2 rounded-lg transition-all duration-200 ease-out hover:scale-105 active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Kembali</span>
        </button>
        <h1 className="text-lg font-semibold truncate max-w-[150px]">{folder.name}</h1>
        <button 
          onClick={() => setShowDeleteConfirm(true)}
          className="p-2 hover:bg-white/10 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
        >
          <Trash2 className="w-5 h-5" />
        </button>
      </header>

      {/* Content */}
      <div className="px-4 py-4">
        {/* Search and Add */}
        <div className="flex gap-3 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Cari script..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-3 rounded-xl bg-white border-0 transition-all duration-300 focus:ring-2 focus:ring-[#2E7D32]"
            />
          </div>
          <Button 
            onClick={() => setShowAddScript(true)}
            className="bg-[#2E7D32] hover:bg-[#1B5E20] text-white rounded-xl px-4 transition-all duration-300 hover:shadow-lg hover:scale-105 active:scale-95"
          >
            <Plus className="w-5 h-5" />
          </Button>
        </div>

        {/* Scripts Count */}
        <p className="text-gray-600 mb-4">{folderScripts.length} script</p>

        {/* Scripts List */}
        <div className="space-y-3">
          {folderScripts.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-2xl transition-all duration-300">
              <p className="text-gray-500">Belum ada script di folder ini</p>
            </div>
          ) : (
            folderScripts.map((script, index) => (
              <div 
                key={script.id}
                className="bg-white rounded-xl p-4 flex items-center gap-4 shadow-sm transition-all duration-300 hover:shadow-lg hover:translate-y-[-2px]"
                style={{ animation: `fadeInUp 0.4s ease-out ${index * 0.05}s both` }}
              >
                <div 
                  className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 cursor-pointer"
                  onClick={() => onViewScript(script)}
                >
                  <img 
                    src={script.thumbnail} 
                    alt={script.title}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                  />
                </div>
                <div 
                  className="flex-1 cursor-pointer"
                  onClick={() => onViewScript(script)}
                >
                  <h4 className="font-semibold text-gray-900">{script.title}</h4>
                  <p className="text-sm text-gray-500">{formatDate(script.createdAt)}</p>
                  <span className="text-xs px-2 py-1 bg-[#E8F5E9] text-[#2E7D32] rounded-full mt-1 inline-block transition-all duration-200">
                    {script.category}
                  </span>
                </div>
                <button 
                  onClick={() => handleEditScript(script)}
                  className="p-2 text-gray-400 hover:text-[#2E7D32] transition-all duration-200 hover:scale-110"
                >
                  <Edit className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => onDeleteScript(script.id)}
                  className="p-2 text-gray-400 hover:text-red-500 transition-all duration-200 hover:scale-110"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Add Script Dialog */}
      <Dialog open={showAddScript} onOpenChange={setShowAddScript}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto animate-scaleIn">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Tambah Script</DialogTitle>
          </DialogHeader>
          <ScriptForm
            key="folder-add-new"
            folders={folders}
            initialFolderId={folder.id}
            initialData={null}
            onSubmit={async (data) => {
              await onAddScript(data);
              setShowAddScript(false);
            }}
            onCancel={() => setShowAddScript(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Script Dialog */}
      <Dialog open={showEditScript && !!editingScript} onOpenChange={(open) => {
        if (!open) {
          setShowEditScript(false);
          setEditingScript(null);
        }
      }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto animate-scaleIn">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Edit Script</DialogTitle>
          </DialogHeader>
          {editingScript && (
            <ScriptForm
              key={`folder-edit-${editingScript.id}`}
              folders={folders}
              initialFolderId={folder.id}
              initialData={editingScript}
              onSubmit={async (data) => {
                await onUpdateScript(editingScript.id, data);
                setShowEditScript(false);
                setEditingScript(null);
              }}
              onCancel={() => {
                setShowEditScript(false);
                setEditingScript(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Folder Confirmation Dialog */}
      <Dialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <DialogContent className="max-w-sm animate-scaleIn">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-center">Hapus Folder?</DialogTitle>
          </DialogHeader>
          <div className="text-center py-4">
            <p className="text-gray-600 mb-2">Apakah Anda yakin ingin menghapus folder</p>
            <p className="font-semibold text-lg text-[#2E7D32]">{folder.name}?</p>
            <p className="text-sm text-gray-500 mt-2">Semua script di folder ini akan dihapus juga.</p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => setShowDeleteConfirm(false)}
              variant="outline"
              className="flex-1 py-3 border-2 border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-all duration-300"
            >
              Batal
            </Button>
            <Button
              onClick={handleDeleteFolder}
              className="flex-1 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl font-medium transition-all duration-300"
            >
              Hapus
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* CSS Animations */}
      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(20px); }
          to { opacity: 1; transform: translateX(0); }
        }
        .animate-slideIn {
          animation: slideIn 0.4s ease-out;
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(15px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-scaleIn {
          animation: scaleIn 0.2s ease-out;
        }
      `}</style>
    </div>
  );
}

// Script Form Component (same as add script form)
function ScriptForm({
  folders,
  initialFolderId,
  initialData,
  onSubmit,
  onCancel
}: {
  folders: Folder[];
  initialFolderId: string;
  initialData: Script | null;
  onSubmit: (data: any) => void;
  onCancel: () => void;
}) {
  const [formData, setFormData] = useState({
    title: initialData?.title || '',
    description: initialData?.description || '',
    thumbnail: initialData?.thumbnail || '',
    banner: initialData?.banner || '',
    folderId: initialData?.folderId || initialFolderId,
    showOnHome: initialData?.showOnHome ?? true,
    category: initialData?.category || 'ASSASIN'
  });

  const [thumbnailPreview, setThumbnailPreview] = useState(initialData?.thumbnail || '');
  const [bannerPreview, setBannerPreview] = useState(initialData?.banner || '');
  const [cropImage, setCropImage] = useState<string | null>(null);
  const [cropAspect, setCropAspect] = useState<number>(1);
  const [cropCallback, setCropCallback] = useState<((cropped: string) => void) | null>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>, aspect: number, callback: (img: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCropImage(reader.result as string);
        setCropAspect(aspect);
        setCropCallback(() => callback);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCropComplete = (croppedImage: string) => {
    if (cropCallback) {
      cropCallback(croppedImage);
    }
    setCropImage(null);
    setCropCallback(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Image Cropper Modal */}
      {cropImage && (
        <ImageCropper
          image={cropImage}
          aspect={cropAspect}
          onCropComplete={handleCropComplete}
          onCancel={() => {
            setCropImage(null);
            setCropCallback(null);
          }}
        />
      )}

      {/* Thumbnail Upload */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Thumbnail (1:1) - Untuk Card <span className="text-red-500">*</span>
        </label>
        <div className="relative">
          <input
            type="file"
            accept="image/*"
            onChange={(e) => handleImageSelect(e, 1, (img) => {
              setThumbnailPreview(img);
              setFormData(prev => ({ ...prev, thumbnail: img }));
            })}
            className="hidden"
            id="script-thumbnail"
          />
          <label 
            htmlFor="script-thumbnail"
            className="block w-full aspect-square max-w-[200px] mx-auto rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 cursor-pointer overflow-hidden transition-all duration-300 hover:border-[#2E7D32] hover:bg-[#E8F5E9]"
          >
            {thumbnailPreview ? (
              <img src={thumbnailPreview} alt="Thumbnail" className="w-full h-full object-cover transition-transform duration-500 hover:scale-105" />
            ) : (
              <div className="flex flex-col items-center justify-center h-full">
                <div className="w-12 h-12 bg-gray-200 rounded-lg flex items-center justify-center mb-2 transition-all duration-300">
                  <Upload className="w-6 h-6 text-gray-400" />
                </div>
                <span className="text-sm text-gray-500 text-center px-4">Klik untuk upload thumbnail 1:1</span>
              </div>
            )}
          </label>
        </div>
      </div>

      {/* Banner Upload */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Banner (16:9) - Untuk Detail
        </label>
        <div className="relative">
          <input
            type="file"
            accept="image/*"
            onChange={(e) => handleImageSelect(e, 16/9, (img) => {
              setBannerPreview(img);
              setFormData(prev => ({ ...prev, banner: img }));
            })}
            className="hidden"
            id="script-banner"
          />
          <label 
            htmlFor="script-banner"
            className="block w-full aspect-video rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 cursor-pointer overflow-hidden transition-all duration-300 hover:border-[#2E7D32] hover:bg-[#E8F5E9]"
          >
            {bannerPreview ? (
              <img src={bannerPreview} alt="Banner" className="w-full h-full object-cover transition-transform duration-500 hover:scale-105" />
            ) : (
              <div className="flex flex-col items-center justify-center h-full">
                <div className="w-12 h-12 bg-gray-200 rounded-lg flex items-center justify-center mb-2 transition-all duration-300">
                  <Upload className="w-6 h-6 text-gray-400" />
                </div>
                <span className="text-sm text-gray-500">Klik untuk upload banner 16:9</span>
                <span className="text-xs text-gray-400 mt-1">(Opsional - jika kosong akan pakai thumbnail)</span>
              </div>
            )}
          </label>
        </div>
      </div>

      {/* Title */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Judul <span className="text-red-500">*</span>
        </label>
        <Input
          value={formData.title}
          onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
          placeholder="Script Skin..."
          className="w-full transition-all duration-300 focus:ring-2 focus:ring-[#2E7D32]"
          required
        />
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Deskripsi & Link
        </label>
        <textarea
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          placeholder="Deskripsi dan link script..."
          rows={4}
          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#2E7D32] focus:ring-2 focus:ring-[#2E7D32] outline-none resize-none transition-all duration-300"
        />
        <p className="text-xs text-gray-500 mt-1">Link akan otomatis bisa diklik</p>
      </div>

      {/* Select Folder */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Pilih Folder
        </label>
        <select
          value={formData.folderId}
          onChange={(e) => setFormData(prev => ({ ...prev, folderId: e.target.value }))}
          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#2E7D32] focus:ring-2 focus:ring-[#2E7D32] outline-none bg-white transition-all duration-300"
        >
          <option value="">Pilih Folder</option>
          {folders.map(folder => (
            <option key={folder.id} value={folder.id}>{folder.name}</option>
          ))}
        </select>
      </div>

      {/* Show on Home */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Tampil di Beranda
        </label>
        <div className="flex gap-3">
          <button
            type="button"
            onClick={() => setFormData(prev => ({ ...prev, showOnHome: true }))}
            className={`flex-1 py-3 px-4 rounded-xl border-2 flex items-center justify-center gap-2 transition-all duration-300 ${
              formData.showOnHome 
                ? 'border-[#2E7D32] bg-[#2E7D32] text-white' 
                : 'border-gray-200 text-gray-700 hover:border-[#2E7D32]'
            }`}
          >
            <User className="w-4 h-4" />
            Tampil di Beranda
          </button>
          <button
            type="button"
            onClick={() => setFormData(prev => ({ ...prev, showOnHome: false }))}
            className={`flex-1 py-3 px-4 rounded-xl border-2 flex items-center justify-center gap-2 transition-all duration-300 ${
              !formData.showOnHome 
                ? 'border-[#2E7D32] bg-[#2E7D32] text-white' 
                : 'border-gray-200 text-gray-700 hover:border-[#2E7D32]'
            }`}
          >
            Tidak di Beranda
          </button>
        </div>
        <div className="flex items-start gap-2 mt-2">
          <span className="text-yellow-500">💡</span>
          <p className="text-xs text-gray-500">Pilih "Tampil di Beranda" agar script muncul di halaman utama</p>
        </div>
      </div>

      {/* Category */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Kategori
        </label>
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, category: cat }))}
              className={`px-4 py-2 rounded-full border-2 text-sm font-medium transition-all duration-300 ${
                formData.category === cat
                  ? 'border-[#2E7D32] bg-[#2E7D32] text-white'
                  : 'border-gray-200 text-gray-700 hover:border-[#2E7D32]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Buttons */}
      <div className="flex gap-3 pt-4">
        <Button
          type="button"
          onClick={onCancel}
          variant="outline"
          className="flex-1 py-4 border-2 border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-all duration-300 hover:border-gray-300"
        >
          Batal
        </Button>
        <Button
          type="submit"
          className="flex-1 py-4 bg-[#2E7D32] hover:bg-[#1B5E20] text-white rounded-xl font-medium transition-all duration-300 hover:shadow-lg hover:translate-y-[-1px]"
        >
          {initialData ? 'Simpan' : 'Tambah'}
        </Button>
      </div>
    </form>
  );
}
