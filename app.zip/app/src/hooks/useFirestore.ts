import { useState, useEffect } from 'react';
import { 
  collection, 
  doc, 
  getDocs, 
  setDoc, 
  deleteDoc, 
  updateDoc, 
  onSnapshot, 
  query, 
  orderBy,
  getDoc,
  writeBatch
} from 'firebase/firestore';
import { db } from '@/firebase';
import type { Script, Folder, Champion, Profile } from '@/types';

const ADMIN_PASSWORD_KEY = 'mlbb_admin_password_v2';

// Collection references
const scriptsCollection = collection(db, 'scripts');
const foldersCollection = collection(db, 'folders');
const championsCollection = collection(db, 'champions');
const profileDoc = doc(db, 'settings', 'profile');

// Compress image to reduce size
async function compressImage(base64String: string, maxWidth: number = 800, quality: number = 0.6): Promise<string> {
  return new Promise((resolve) => {
    // Skip if already compressed or is URL
    if (!base64String.startsWith('data:image')) {
      resolve(base64String);
      return;
    }
    
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;
      
      // Resize if too large
      if (width > maxWidth) {
        height = (height * maxWidth) / width;
        width = maxWidth;
      }
      
      canvas.width = width;
      canvas.height = height;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      } else {
        resolve(base64String);
      }
    };
    img.onerror = () => resolve(base64String);
    img.src = base64String;
  });
}

// Compress script images before saving
async function compressScript(script: Script): Promise<Script> {
  const compressed = { ...script };
  if (script.thumbnail && script.thumbnail.startsWith('data:image')) {
    compressed.thumbnail = await compressImage(script.thumbnail, 400, 0.5);
  }
  if (script.banner && script.banner.startsWith('data:image')) {
    compressed.banner = await compressImage(script.banner, 600, 0.5);
  }
  return compressed;
}

// Compress profile images
async function compressProfile(profile: Profile): Promise<Profile> {
  const compressed = { ...profile };
  if (profile.avatar && profile.avatar.startsWith('data:image')) {
    compressed.avatar = await compressImage(profile.avatar, 200, 0.5);
  }
  if (profile.banner && profile.banner.startsWith('data:image')) {
    compressed.banner = await compressImage(profile.banner, 600, 0.5);
  }
  return compressed;
}

export const defaultProfile: Profile = {
  username: '@reizenofficial',
  banner: 'https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?w=800',
  avatar: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400',
  description: 'Download Script Skin MLBB & More! 🎮\nAll scripts are free and no password.'
};

export const defaultFolders: Folder[] = [
  { id: '1', name: 'S.A.B.E.R', scriptCount: 0 },
  { id: '2', name: 'V.E.N.O.M', scriptCount: 0 },
  { id: '3', name: 'Lightborn', scriptCount: 0 },
  { id: '4', name: 'Blazing', scriptCount: 0 },
  { id: '5', name: 'Dragon Tamer', scriptCount: 0 },
  { id: '6', name: 'Aspirants', scriptCount: 0 },
  { id: '7', name: 'Atomic Pop', scriptCount: 0 },
  { id: '8', name: '515 Squad', scriptCount: 0 },
  { id: '9', name: 'Kung Fu Panda', scriptCount: 0 },
  { id: '10', name: 'Star Wars', scriptCount: 0 },
  { id: '11', name: 'Transformers', scriptCount: 0 },
  { id: '12', name: 'KOF', scriptCount: 0 },
  { id: '13', name: 'Sanrio', scriptCount: 0 },
  { id: '14', name: 'Jujutsu Kaisen', scriptCount: 0 },
  { id: '15', name: 'Exorcist', scriptCount: 0 },
  { id: '16', name: 'Neobeasts', scriptCount: 0 },
  { id: '17', name: 'Zodiac', scriptCount: 0 },
  { id: '18', name: 'Ducati', scriptCount: 0 },
  { id: '19', name: 'Saint Seiya', scriptCount: 0 },
  { id: '20', name: 'Hunter x Hunter', scriptCount: 0 },
  { id: '21', name: 'Nexus Sea', scriptCount: 0 },
  { id: '22', name: '11.11', scriptCount: 0 }
];

export const defaultChampions: Champion[] = [
  { id: '1', name: 'Lancelot', thumbnail: 'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=200', role: 'ASSASIN' },
  { id: '2', name: 'Harith', thumbnail: 'https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?w=200', role: 'MAGE' },
  { id: '3', name: 'Joy', thumbnail: 'https://images.unsplash.com/photo-1614680376576-d87f6f5b5b6c?w=200', role: 'FIGHTER' }
];

// Initialize default data in Firestore
async function initializeDefaultData() {
  try {
    // Check if folders exist
    const foldersSnapshot = await getDocs(foldersCollection);
    if (foldersSnapshot.empty) {
      // Add default folders
      const batch = writeBatch(db);
      for (const folder of defaultFolders) {
        const folderRef = doc(foldersCollection, folder.id);
        batch.set(folderRef, folder);
      }
      await batch.commit();
      console.log('Default folders initialized');
    }

    // Check if champions exist
    const championsSnapshot = await getDocs(championsCollection);
    if (championsSnapshot.empty) {
      // Add default champions
      const batch = writeBatch(db);
      for (const champion of defaultChampions) {
        const championRef = doc(championsCollection, champion.id);
        batch.set(championRef, champion);
      }
      await batch.commit();
      console.log('Default champions initialized');
    }

    // Check if profile exists
    const profileSnapshot = await getDoc(profileDoc);
    if (!profileSnapshot.exists()) {
      await setDoc(profileDoc, defaultProfile);
      console.log('Default profile initialized');
    }
  } catch (error) {
    console.error('Error initializing default data:', error);
  }
}

export function useScripts() {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    // Initialize default data first
    initializeDefaultData();

    // Subscribe to real-time updates
    const q = query(scriptsCollection, orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const scriptsData: Script[] = [];
      snapshot.forEach((doc) => {
        scriptsData.push({ id: doc.id, ...doc.data() } as Script);
      });
      setScripts(scriptsData);
      setLoaded(true);
    }, (error) => {
      console.error('Error loading scripts:', error);
      setLoaded(true);
    });

    return () => unsubscribe();
  }, []);

  const addScript = async (script: Omit<Script, 'id' | 'createdAt' | 'views'>) => {
    const newScript: Script = {
      ...script,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      views: 0
    };
    // Compress images before adding
    const compressed = await compressScript(newScript);
    await setDoc(doc(scriptsCollection, compressed.id), compressed);
    return compressed;
  };

  const updateScript = async (id: string, updates: Partial<Script>) => {
    const scriptRef = doc(scriptsCollection, id);
    let updatedData = { ...updates };
    
    // Compress if image updated
    if (updates.thumbnail?.startsWith('data:image') || updates.banner?.startsWith('data:image')) {
      const currentDoc = await getDoc(scriptRef);
      if (currentDoc.exists()) {
        const currentData = currentDoc.data() as Script;
        const updatedScript = { ...currentData, ...updates };
        const compressed = await compressScript(updatedScript);
        updatedData = { 
          thumbnail: compressed.thumbnail, 
          banner: compressed.banner 
        };
      }
    }
    
    await updateDoc(scriptRef, updatedData);
  };

  const deleteScript = async (id: string) => {
    await deleteDoc(doc(scriptsCollection, id));
  };

  const incrementViews = async (id: string) => {
    const scriptRef = doc(scriptsCollection, id);
    const script = scripts.find(s => s.id === id);
    if (script) {
      await updateDoc(scriptRef, { views: (script.views || 0) + 1 });
    }
  };

  return { scripts, addScript, updateScript, deleteScript, incrementViews, loaded };
}

export function useFolders() {
  const [folders, setFolders] = useState<Folder[]>(defaultFolders);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    // Initialize default data first
    initializeDefaultData();

    // Subscribe to real-time updates
    const unsubscribe = onSnapshot(foldersCollection, (snapshot) => {
      const foldersData: Folder[] = [];
      snapshot.forEach((doc) => {
        foldersData.push({ id: doc.id, ...doc.data() } as Folder);
      });
      if (foldersData.length > 0) {
        setFolders(foldersData);
      }
      setLoaded(true);
    }, (error) => {
      console.error('Error loading folders:', error);
      setLoaded(true);
    });

    return () => unsubscribe();
  }, []);

  const addFolder = async (name: string) => {
    const newFolder: Folder = {
      id: Date.now().toString(),
      name,
      scriptCount: 0
    };
    await setDoc(doc(foldersCollection, newFolder.id), newFolder);
    return newFolder;
  };

  const deleteFolder = async (folderId: string) => {
    await deleteDoc(doc(foldersCollection, folderId));
  };

  const updateScriptCount = async (folderId: string, delta: number) => {
    const folderRef = doc(foldersCollection, folderId);
    const folder = folders.find(f => f.id === folderId);
    if (folder) {
      await updateDoc(folderRef, { 
        scriptCount: Math.max(0, (folder.scriptCount || 0) + delta) 
      });
    }
  };

  return { folders, addFolder, deleteFolder, updateScriptCount, loaded };
}

export function useChampions() {
  const [champions, setChampions] = useState<Champion[]>(defaultChampions);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    // Initialize default data first
    initializeDefaultData();

    // Subscribe to real-time updates
    const unsubscribe = onSnapshot(championsCollection, (snapshot) => {
      const championsData: Champion[] = [];
      snapshot.forEach((doc) => {
        championsData.push({ id: doc.id, ...doc.data() } as Champion);
      });
      if (championsData.length > 0) {
        setChampions(championsData);
      }
      setLoaded(true);
    }, (error) => {
      console.error('Error loading champions:', error);
      setLoaded(true);
    });

    return () => unsubscribe();
  }, []);

  const addChampion = async (champion: Omit<Champion, 'id'>) => {
    const newChampion: Champion = {
      ...champion,
      id: Date.now().toString()
    };
    // Compress thumbnail
    if (newChampion.thumbnail?.startsWith('data:image')) {
      newChampion.thumbnail = await compressImage(newChampion.thumbnail, 200, 0.5);
    }
    await setDoc(doc(championsCollection, newChampion.id), newChampion);
    return newChampion;
  };

  const updateChampion = async (id: string, updates: Partial<Champion>) => {
    const championRef = doc(championsCollection, id);
    let updatedData = { ...updates };
    
    if (updates.thumbnail?.startsWith('data:image')) {
      updatedData.thumbnail = await compressImage(updates.thumbnail, 200, 0.5);
    }
    
    await updateDoc(championRef, updatedData);
  };

  const deleteChampion = async (id: string) => {
    await deleteDoc(doc(championsCollection, id));
  };

  return { champions, addChampion, updateChampion, deleteChampion, loaded };
}

export function useProfile() {
  const [profile, setProfile] = useState<Profile>(defaultProfile);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    // Initialize default data first
    initializeDefaultData();

    // Subscribe to real-time updates
    const unsubscribe = onSnapshot(profileDoc, (snapshot) => {
      if (snapshot.exists()) {
        setProfile(snapshot.data() as Profile);
      }
      setLoaded(true);
    }, (error) => {
      console.error('Error loading profile:', error);
      setLoaded(true);
    });

    return () => unsubscribe();
  }, []);

  const updateProfile = async (updates: Partial<Profile>) => {
    const updatedProfile = { ...profile, ...updates };
    const compressed = await compressProfile(updatedProfile);
    await setDoc(profileDoc, compressed);
  };

  return { profile, updateProfile, loaded };
}

export function useAdminAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const stored = sessionStorage.getItem('mlbb_admin_auth');
    if (stored === 'true') {
      setIsAuthenticated(true);
    }
  }, []);

  const login = (password: string): boolean => {
    const storedPassword = localStorage.getItem(ADMIN_PASSWORD_KEY) || 'kyah231';
    if (password === storedPassword) {
      setIsAuthenticated(true);
      sessionStorage.setItem('mlbb_admin_auth', 'true');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('mlbb_admin_auth');
  };

  const changePassword = (newPassword: string) => {
    localStorage.setItem(ADMIN_PASSWORD_KEY, newPassword);
  };

  return { isAuthenticated, login, logout, changePassword };
}
