import { useState, useEffect, useCallback } from 'react';
import localforage from 'localforage';
import type { Script, Folder, Champion, Profile } from '@/types';

const ADMIN_PASSWORD_KEY = 'mlbb_admin_password_v2';

// Configure localforage instances
const scriptsDB = localforage.createInstance({
  name: 'MLBBScripts',
  storeName: 'scripts',
  description: 'Storage for MLBB scripts'
});

const foldersDB = localforage.createInstance({
  name: 'MLBBScripts',
  storeName: 'folders',
  description: 'Storage for folders'
});

const championsDB = localforage.createInstance({
  name: 'MLBBScripts',
  storeName: 'champions',
  description: 'Storage for champions'
});

const profileDB = localforage.createInstance({
  name: 'MLBBScripts',
  storeName: 'profile',
  description: 'Storage for profile'
});

// Compress image to reduce size
async function compressImage(base64String: string, maxWidth: number = 800, quality: number = 0.6): Promise<string> {
  return new Promise((resolve) => {
    // Skip if already compressed or is URL
    if (!base64String.startsWith('data:image')) {
      resolve(base64String);
      return;
    }
    
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;
      
      // Resize if too large
      if (width > maxWidth) {
        height = (height * maxWidth) / width;
        width = maxWidth;
      }
      
      canvas.width = width;
      canvas.height = height;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      } else {
        resolve(base64String);
      }
    };
    img.onerror = () => resolve(base64String);
    img.src = base64String;
  });
}

// Compress script images before saving
async function compressScript(script: Script): Promise<Script> {
  const compressed = { ...script };
  if (script.thumbnail && script.thumbnail.startsWith('data:image')) {
    compressed.thumbnail = await compressImage(script.thumbnail, 400, 0.5);
  }
  if (script.banner && script.banner.startsWith('data:image')) {
    compressed.banner = await compressImage(script.banner, 600, 0.5);
  }
  return compressed;
}

// Compress profile images
async function compressProfile(profile: Profile): Promise<Profile> {
  const compressed = { ...profile };
  if (profile.avatar && profile.avatar.startsWith('data:image')) {
    compressed.avatar = await compressImage(profile.avatar, 200, 0.5);
  }
  if (profile.banner && profile.banner.startsWith('data:image')) {
    compressed.banner = await compressImage(profile.banner, 600, 0.5);
  }
  return compressed;
}

export const defaultProfile: Profile = {
  username: '@reizenofficial',
  banner: 'https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?w=800',
  avatar: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400',
  description: 'Download Script Skin MLBB & More! 🎮\nAll scripts are free and no password.'
};

export const defaultFolders: Folder[] = [
  { id: '1', name: 'S.A.B.E.R', scriptCount: 0 },
  { id: '2', name: 'V.E.N.O.M', scriptCount: 0 },
  { id: '3', name: 'Lightborn', scriptCount: 0 },
  { id: '4', name: 'Blazing', scriptCount: 0 },
  { id: '5', name: 'Dragon Tamer', scriptCount: 0 },
  { id: '6', name: 'Aspirants', scriptCount: 0 },
  { id: '7', name: 'Atomic Pop', scriptCount: 0 },
  { id: '8', name: '515 Squad', scriptCount: 0 },
  { id: '9', name: 'Kung Fu Panda', scriptCount: 0 },
  { id: '10', name: 'Star Wars', scriptCount: 0 },
  { id: '11', name: 'Transformers', scriptCount: 0 },
  { id: '12', name: 'KOF', scriptCount: 0 },
  { id: '13', name: 'Sanrio', scriptCount: 0 },
  { id: '14', name: 'Jujutsu Kaisen', scriptCount: 0 },
  { id: '15', name: 'Exorcist', scriptCount: 0 },
  { id: '16', name: 'Neobeasts', scriptCount: 0 },
  { id: '17', name: 'Zodiac', scriptCount: 0 },
  { id: '18', name: 'Ducati', scriptCount: 0 },
  { id: '19', name: 'Saint Seiya', scriptCount: 0 },
  { id: '20', name: 'Hunter x Hunter', scriptCount: 0 },
  { id: '21', name: 'Nexus Sea', scriptCount: 0 },
  { id: '22', name: '11.11', scriptCount: 0 }
];

export const defaultChampions: Champion[] = [
  { id: '1', name: 'Lancelot', thumbnail: 'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=200', role: 'ASSASIN' },
  { id: '2', name: 'Harith', thumbnail: 'https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?w=200', role: 'MAGE' },
  { id: '3', name: 'Joy', thumbnail: 'https://images.unsplash.com/photo-1614680376576-d87f6f5b5b6c?w=200', role: 'FIGHTER' }
];

export function useScripts() {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const loadScripts = async () => {
      try {
        const stored = await scriptsDB.getItem<Script[]>('data');
        if (stored && Array.isArray(stored)) {
          setScripts(stored);
        }
      } catch (e) {
        console.error('Error loading scripts:', e);
      }
      setLoaded(true);
    };
    loadScripts();
  }, []);

  const saveScripts = useCallback(async (newScripts: Script[]) => {
    try {
      await scriptsDB.setItem('data', newScripts);
    } catch (e) {
      console.error('Error saving scripts:', e);
    }
  }, []);

  const addScript = async (script: Omit<Script, 'id' | 'createdAt' | 'views'>) => {
    const newScript: Script = {
      ...script,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      views: 0
    };
    // Compress images before adding
    const compressed = await compressScript(newScript);
    const updated = [compressed, ...scripts];
    setScripts(updated);
    await saveScripts(updated);
    return compressed;
  };

  const updateScript = async (id: string, updates: Partial<Script>) => {
    const scriptToUpdate = scripts.find(s => s.id === id);
    if (!scriptToUpdate) return;
    
    let updated = { ...scriptToUpdate, ...updates };
    // Compress if image updated
    if (updates.thumbnail?.startsWith('data:image') || updates.banner?.startsWith('data:image')) {
      updated = await compressScript(updated);
    }
    
    const updatedScripts = scripts.map(s => s.id === id ? updated : s);
    setScripts(updatedScripts);
    await saveScripts(updatedScripts);
  };

  const deleteScript = async (id: string) => {
    const updated = scripts.filter(s => s.id !== id);
    setScripts(updated);
    await saveScripts(updated);
  };

  const incrementViews = (id: string) => {
    const updated = scripts.map(s => s.id === id ? { ...s, views: s.views + 1 } : s);
    setScripts(updated);
    saveScripts(updated);
  };

  const importScripts = async (newScripts: Script[]) => {
    setScripts(newScripts);
    await saveScripts(newScripts);
  };

  return { scripts, addScript, updateScript, deleteScript, incrementViews, importScripts, loaded };
}

export function useFolders() {
  const [folders, setFolders] = useState<Folder[]>(defaultFolders);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const loadFolders = async () => {
      try {
        const stored = await foldersDB.getItem<Folder[]>('data');
        if (stored && Array.isArray(stored) && stored.length > 0) {
          setFolders(stored);
        }
      } catch (e) {
        console.error('Error loading folders:', e);
      }
      setLoaded(true);
    };
    loadFolders();
  }, []);

  const saveFolders = useCallback(async (newFolders: Folder[]) => {
    try {
      await foldersDB.setItem('data', newFolders);
    } catch (e) {
      console.error('Error saving folders:', e);
    }
  }, []);

  const addFolder = async (name: string) => {
    const newFolder: Folder = {
      id: Date.now().toString(),
      name,
      scriptCount: 0
    };
    const updated = [...folders, newFolder];
    setFolders(updated);
    await saveFolders(updated);
    return newFolder;
  };

  const deleteFolder = async (folderId: string) => {
    const updated = folders.filter(f => f.id !== folderId);
    setFolders(updated);
    await saveFolders(updated);
  };

  const updateScriptCount = (folderId: string, delta: number) => {
    const updated = folders.map(f => 
      f.id === folderId ? { ...f, scriptCount: Math.max(0, f.scriptCount + delta) } : f
    );
    setFolders(updated);
    saveFolders(updated);
  };

  const importFolders = async (newFolders: Folder[]) => {
    setFolders(newFolders);
    await saveFolders(newFolders);
  };

  return { folders, addFolder, deleteFolder, updateScriptCount, importFolders, loaded };
}

export function useChampions() {
  const [champions, setChampions] = useState<Champion[]>(defaultChampions);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const loadChampions = async () => {
      try {
        const stored = await championsDB.getItem<Champion[]>('data');
        if (stored && Array.isArray(stored) && stored.length > 0) {
          setChampions(stored);
        }
      } catch (e) {
        console.error('Error loading champions:', e);
      }
      setLoaded(true);
    };
    loadChampions();
  }, []);

  const saveChampions = useCallback(async (newChampions: Champion[]) => {
    try {
      await championsDB.setItem('data', newChampions);
    } catch (e) {
      console.error('Error saving champions:', e);
    }
  }, []);

  const addChampion = async (champion: Omit<Champion, 'id'>) => {
    const newChampion: Champion = {
      ...champion,
      id: Date.now().toString()
    };
    // Compress thumbnail
    if (newChampion.thumbnail?.startsWith('data:image')) {
      newChampion.thumbnail = await compressImage(newChampion.thumbnail, 200, 0.5);
    }
    const updated = [...champions, newChampion];
    setChampions(updated);
    await saveChampions(updated);
    return newChampion;
  };

  const updateChampion = async (id: string, updates: Partial<Champion>) => {
    if (updates.thumbnail?.startsWith('data:image')) {
      updates.thumbnail = await compressImage(updates.thumbnail, 200, 0.5);
    }
    const updated = champions.map(c => c.id === id ? { ...c, ...updates } : c);
    setChampions(updated);
    await saveChampions(updated);
  };

  const deleteChampion = async (id: string) => {
    const updated = champions.filter(c => c.id !== id);
    setChampions(updated);
    await saveChampions(updated);
  };

  const importChampions = async (newChampions: Champion[]) => {
    setChampions(newChampions);
    await saveChampions(newChampions);
  };

  return { champions, addChampion, updateChampion, deleteChampion, importChampions, loaded };
}

export function useProfile() {
  const [profile, setProfile] = useState<Profile>(defaultProfile);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const stored = await profileDB.getItem<Profile>('data');
        if (stored) {
          setProfile(stored);
        }
      } catch (e) {
        console.error('Error loading profile:', e);
      }
      setLoaded(true);
    };
    loadProfile();
  }, []);

  const saveProfile = useCallback(async (newProfile: Profile) => {
    try {
      const compressed = await compressProfile(newProfile);
      await profileDB.setItem('data', compressed);
    } catch (e) {
      console.error('Error saving profile:', e);
    }
  }, []);

  const updateProfile = (updates: Partial<Profile>) => {
    const updated = { ...profile, ...updates };
    setProfile(updated);
    saveProfile(updated);
  };

  const importProfile = async (newProfile: Profile) => {
    setProfile(newProfile);
    await saveProfile(newProfile);
  };

  return { profile, updateProfile, importProfile, loaded };
}

export function useAdminAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const stored = sessionStorage.getItem('mlbb_admin_auth');
    if (stored === 'true') {
      setIsAuthenticated(true);
    }
  }, []);

  const login = (password: string): boolean => {
    const storedPassword = localStorage.getItem(ADMIN_PASSWORD_KEY) || 'kyah231';
    if (password === storedPassword) {
      setIsAuthenticated(true);
      sessionStorage.setItem('mlbb_admin_auth', 'true');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('mlbb_admin_auth');
  };

  const changePassword = (newPassword: string) => {
    localStorage.setItem(ADMIN_PASSWORD_KEY, newPassword);
  };

  return { isAuthenticated, login, logout, changePassword };
}
