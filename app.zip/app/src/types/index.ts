export interface Script {
  id: string;
  title: string;
  thumbnail: string;
  banner?: string;
  description: string;
  folderId?: string;
  showOnHome: boolean;
  category: 'ASSASIN' | 'MAGE' | 'MARKSMAN' | 'TANK' | 'FIGHTER' | 'SUPPORT';
  createdAt: string;
  views: number;
}

export interface Folder {
  id: string;
  name: string;
  scriptCount: number;
}

export interface Champion {
  id: string;
  name: string;
  thumbnail: string;
  role: 'ASSASIN' | 'MAGE' | 'MARKSMAN' | 'TANK' | 'FIGHTER' | 'SUPPORT';
}

export interface Profile {
  username: string;
  banner: string;
  avatar: string;
  description: string;
}

export const SQUAD_FOLDERS = [
  'S.A.B.E.R',
  'V.E.N.O.M',
  'Lightborn',
  'Blazing',
  'Dragon Tamer',
  'Aspirants',
  'Atomic Pop',
  '515 Squad',
  'Kung Fu Panda',
  'Star Wars',
  'Transformers',
  'KOF',
  'Sanrio',
  'Jujutsu Kaisen',
  'Exorcist',
  'Neobeasts',
  'Zodiac',
  'Ducati',
  'Saint Seiya',
  'Hunter x Hunter',
  'Nexus Sea',
  '11.11'
] as const;

export const CATEGORIES = [
  'ASSASIN',
  'MAGE',
  'MARKSMAN',
  'TANK',
  'FIGHTER',
  'SUPPORT'
] as const;
