import { initializeApp } from 'firebase/app';
import { getFirestore, collection, doc, getDocs, setDoc, deleteDoc, updateDoc, onSnapshot, query, orderBy } from 'firebase/firestore';

// Firebase configuration - using a public demo project
// Replace with your own Firebase config if needed
const firebaseConfig = {
  apiKey: "AIzaSyDemoKeyForMLBBScriptSkin",
  authDomain: "mlbb-script-skin.firebaseapp.com",
  projectId: "mlbb-script-skin",
  storageBucket: "mlbb-script-skin.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef123456"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

// Collection references
export const scriptsCollection = collection(db, 'scripts');
export const foldersCollection = collection(db, 'folders');
export const championsCollection = collection(db, 'champions');
export const profileDoc = doc(db, 'settings', 'profile');

export { 
  collection, 
  doc, 
  getDocs, 
  setDoc, 
  deleteDoc, 
  updateDoc, 
  onSnapshot,
  query,
  orderBy 
};
