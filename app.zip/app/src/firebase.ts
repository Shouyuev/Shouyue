import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyBmvP71n5xK9z-6YOlzoXTnKb7B2QTOIlE",
  authDomain: "mlbb-script-skin-1c495.firebaseapp.com",
  projectId: "mlbb-script-skin-1c495",
  storageBucket: "mlbb-script-skin-1c495.firebasestorage.app",
  messagingSenderId: "782560684874",
  appId: "1:782560684874:web:5a733df7e6e9d07203efb3",
  measurementId: "G-9VG9Z7D7VQ"
};

const app = initializeApp(firebaseConfig);

export default app;